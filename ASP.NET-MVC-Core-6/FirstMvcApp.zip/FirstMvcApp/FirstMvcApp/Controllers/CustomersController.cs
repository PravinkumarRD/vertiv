﻿using FirstMvcApp.Models;
using Microsoft.AspNetCore.Mvc;

namespace FirstMvcApp.Controllers
{
    public class CustomersController : Controller
    {
        private readonly List<Customer> _customers;
        public CustomersController()
        {
            _customers = new List<Customer>()
            {
                new Customer() {CustomerId= 1,ContactName="Alisha C.",City="Mumbai" },
                new Customer() {CustomerId= 2,ContactName="Manish Kaushik",City="Bangalore" },
                new Customer() {CustomerId= 3,ContactName="Maria Andrus",City="Berlin" }
            };
        }
        //Customers
        public IActionResult Index()
        {
            return Content("<h1>Welcome To Vertiv!</h1><hr/><h6>Core Development Center!</h6>", "text/html");
        }
        //Customers/Data
        public IActionResult Data()
        {
            return Json(_customers);
        }
        //Customers/Contact
        public IActionResult Contact()
        {
            return View();
        }
        //Customers/List
        public IActionResult List()
        {
            if (DateTime.Now.Hour<23)
            {
                return View("VertivCustomerList", _customers);
            }
            else
            {
                return View("VertivCustomerListPune", _customers);
            } 
        }
    }
}
