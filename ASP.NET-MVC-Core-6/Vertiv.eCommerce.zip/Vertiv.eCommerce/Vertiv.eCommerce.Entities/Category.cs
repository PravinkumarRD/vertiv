﻿using System.ComponentModel.DataAnnotations;

namespace Vertiv.eCommerce.Entities
{
    public class Category
    {
        public int CategoryId { get; set; }
        [MaxLength(30,ErrorMessage ="Category Name cannot be more than 30 characters!")]
        [Required(ErrorMessage ="Category Name is required field!")]
        public string CategoryName { get; set; } = string.Empty;
        [MaxLength(300, ErrorMessage = "Category Description cannot be more than 300 characters!")]
        [Required(ErrorMessage = "Category Description is required field!")]
        public string Description { get; set; } = string.Empty;
        public virtual ICollection<Product>? Products { get; set; }
    }
}