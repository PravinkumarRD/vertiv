﻿using Microsoft.EntityFrameworkCore;
using Vertiv.eCommerce.Entities;

namespace Vertiv.eCommerce.Dal
{
    public class VertiveCommerceDbContext : DbContext
    {
        public VertiveCommerceDbContext()
        {

        }
        public VertiveCommerceDbContext(DbContextOptions options) : base(options)
        {
        }
        public virtual DbSet<Category> Categories { get; set; }
        public virtual DbSet<Product> Products { get; set; }
        public virtual DbSet<Customer> Customers { get; set; }
        public virtual DbSet<Cart> Carts { get; set; }
        public virtual DbSet<CartDetail> CartDetails { get; set; }
        public virtual DbSet<Invoice> Invoices { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=localhost;Initial Catalog=VertivECommerceDb;Trusted_Connection=true;TrustServerCertificate=True");
            }
        }
    }
}
