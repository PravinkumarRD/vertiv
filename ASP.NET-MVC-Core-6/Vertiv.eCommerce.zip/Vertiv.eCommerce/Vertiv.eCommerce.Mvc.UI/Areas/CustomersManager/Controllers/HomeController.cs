﻿using Microsoft.AspNetCore.Mvc;

namespace Vertiv.eCommerce.Mvc.UI.Areas.CustomersManager.Controllers
{
    [Area("CustomersManager")]
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
