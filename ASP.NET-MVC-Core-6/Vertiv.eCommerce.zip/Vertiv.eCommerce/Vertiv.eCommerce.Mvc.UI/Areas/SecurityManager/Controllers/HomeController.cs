﻿using Microsoft.AspNetCore.Mvc;

namespace Vertiv.eCommerce.Mvc.UI.Areas.SecurityManager.Controllers
{
    [Area("SecurityManager")]
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
