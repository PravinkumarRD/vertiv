﻿using Microsoft.AspNetCore.Mvc;

namespace Vertiv.eCommerce.Mvc.UI.Areas.ProductsManager.Controllers
{
    [Area("ProductsManager")]
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.PageTitle = "Welcome To Vertiv Products List!";
            ViewBag.PageSubTitle = "Most Populaor Products in the world!";
            return View();
        }
    }
}
