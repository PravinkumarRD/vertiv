﻿using FirstRESTApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FirstRESTApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VertivEmployeesController : ControllerBase
    {
        private readonly List<Employee> _employees;
        public VertivEmployeesController()
        {
            _employees = new List<Employee>()
            {
                new Employee(){EmployeeId=100,EmployeeName="Amit T.",City="Pune"},
                new Employee(){EmployeeId=101,EmployeeName="Alicia Steav",City="London"},
                new Employee(){EmployeeId=102,EmployeeName="Pravinkumar R. D.",City="Delhi"},
            };
        }

        //[ProducesResponseType(StatusCodes.Status200OK,Type = typeof(IEnumerable<Employee>))]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [HttpGet]
        //public IActionResult Get()
        public ActionResult<IEnumerable<Employee>> Get()
        {
            if (_employees.Count > 0)
            {
                return Ok(_employees);
            }
            return NotFound();
        }
        [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(Employee))]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [HttpGet("{id:int}")]
        public IActionResult Get(int id)
        {
            var employee = _employees.Find(e => e.EmployeeId == id);
            if (employee != null)
            {
                return Ok(employee);
            }
            return NotFound();
        }
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [HttpPost]
        public ActionResult<Employee> Post(Employee employee)
        {
            _employees.Add(new Employee());
            return CreatedAtAction("Get", employee);
        }
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [HttpPut]
        public ActionResult<Employee> Put(Employee employee)
        {
            var existingEmployee = _employees.Find(emp => emp.EmployeeId == employee.EmployeeId);
            if (existingEmployee != null)
            {
                existingEmployee.EmployeeName = employee.EmployeeName;
                existingEmployee.City= employee.City;
                return NoContent();
            }
            else
            {
                return NotFound();
            }
        }
    }
}
