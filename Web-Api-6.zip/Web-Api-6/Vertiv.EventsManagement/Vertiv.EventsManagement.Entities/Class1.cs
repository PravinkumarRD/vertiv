﻿namespace Vertiv.EventsManagement.Entities
{
    public class Class1
    {

    }
}