﻿namespace Vertiv.EventsManagement.Dal
{
    public class Class1
    {

    }
}