﻿using Microsoft.EntityFrameworkCore;
using Vertiv.PurchaseOrder.Entities;
Console.WriteLine("Display Customers!");
var poDbContext = new PurchaseOrderDbContext();
poDbContext.Customers.ToList().ForEach(customer => Console.WriteLine($"Customer {customer.ContactName} lives in {customer.City}!"));
Console.WriteLine("");
Console.WriteLine("Display Total Customers in Each City!");

var TotalCustomersInEachCity = from customer in poDbContext.Customers
                               group customer by customer.City into grpOutput
                               select new { City=grpOutput.Key, Count=grpOutput.Count()};
foreach (var item in TotalCustomersInEachCity)
{
    Console.WriteLine($"In city {item.City} there is/are {item.Count} number of customers!");
}
#region Fetching Data From SPs
string city = "London";
var Customers = poDbContext.Customers.FromSqlRaw($"exec CityWiseCustomers {city}").ToList();
Console.WriteLine("");
foreach (var customer in Customers)
{
    Console.WriteLine($"Customer {customer.ContactName} lives in {customer.City}!");
}
#endregion
#region Insert/Update/Delete from SPs
string name = "Amit T.";
string livingCity = "Pune";
//poDbContext.Database.ExecuteSqlRaw($"EXEC InsertCustomer {name}, {livingCity}");
#endregion
Console.WriteLine("");
poDbContext.CategoryWiseProducts.ToList().ForEach(catProd => Console.WriteLine($"Category Name - {catProd.CategoryName}! Product Name - {catProd.ProductName}"));

//Eager Loading
var AllCategories = poDbContext.Categories.Include("Products").ToList();
Console.ReadKey();
