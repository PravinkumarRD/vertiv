﻿using System.ComponentModel.DataAnnotations;

namespace Vertiv.PurchaseOrder.Entities
{
    public class Shipper
    {
        public int ShipperId { get; set; }
        [MaxLength(100)]
        public string ShipperName { get; set; } = string.Empty;
        public int SocialId { get; set; }
        [MaxLength(100)]
        public string Email { get; set; } = string.Empty;
        public int ContactNumber { get; set; }
        [MaxLength(100)]
        public string City { get; set; } = string.Empty;
        public virtual ICollection<Supplier>? Suppliers { get; set; }

    }
}
