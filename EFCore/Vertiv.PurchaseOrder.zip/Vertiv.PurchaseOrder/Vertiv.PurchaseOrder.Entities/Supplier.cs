﻿using System.ComponentModel.DataAnnotations;

namespace Vertiv.PurchaseOrder.Entities
{
    public class Supplier
    {
        public int SupplierId { get; set; }
        [MaxLength(100)]
        public string SupplierName { get; set; } = string.Empty;
        [MaxLength(100)]
        public string CompanyName { get; set; } = string.Empty;
        [MaxLength(100)]
        public string Email { get; set; } = string.Empty;
        public int ContactNumber { get; set; }
        public virtual ICollection<Shipper>? Shippers { get; set; }
        public virtual ICollection<Order>? Orders { get; set; }
    }
}
