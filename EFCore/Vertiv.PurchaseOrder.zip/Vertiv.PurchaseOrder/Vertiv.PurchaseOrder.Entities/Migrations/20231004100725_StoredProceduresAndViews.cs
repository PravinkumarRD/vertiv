﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Vertiv.PurchaseOrder.Entities.Migrations
{
    /// <inheritdoc />
    public partial class StoredProceduresAndViews : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql($"Create View CategoryWiseProducts AS " +
                $"select c.CategoryName, p.ProductName, p.UnitPrice, p.AvailableQuantity from Categories c INNER JOIN Products p on c.CategoryId=p.CategoryId");

            var sp = @"CREATE PROCEDURE [dbo].[CityWiseCustomers]
                    @p_City varchar(50)
                AS
                BEGIN
                    SET NOCOUNT ON;
                    select * from Customers where city=@p_City;
                END";
            migrationBuilder.Sql(sp);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("Drop View CategoryWiseProducts");
            migrationBuilder.Sql("Drop Procedure CityWiseCustomers");
        }
    }
}
