﻿using System.ComponentModel.DataAnnotations;

namespace Vertiv.PurchaseOrder.Entities
{
    public class Category
    {
        [Key]
        public int CategoryId { get; set; }
        [StringLength(100)]
        public string CategoryName { get; set; } = string.Empty;
        [StringLength(500)]
        public string Description { get; set; } = string.Empty;
        public virtual ICollection<Product> Products { get; set; }
    }
}