﻿using Microsoft.EntityFrameworkCore;

namespace Vertiv.PurchaseOrder.Entities
{
    public class PurchaseOrderDbContext:DbContext
    {
        public PurchaseOrderDbContext()
        {

        }
        public PurchaseOrderDbContext(DbContextOptions<PurchaseOrderDbContext> options):base(options)
        {

        }
        public virtual DbSet<Category> Categories { get; set; }
        public virtual DbSet<Product> Products { get; set; }
        public virtual DbSet<Customer> Customers { get; set; }
        public virtual DbSet<Order> Orders { get; set; }
        public virtual DbSet<OrderDetail> OrderDetails { get; set; }
        public virtual DbSet<Supplier> Suppliers { get; set; }
        public virtual DbSet<Shipper> Shippers { get; set; }
        public virtual DbSet<CategoryWiseProducts> CategoryWiseProducts { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=localhost;Initial Catalog=VertivPoDb;Trusted_Connection=true;TrustServerCertificate=True;");
                optionsBuilder.LogTo(Console.WriteLine);
                optionsBuilder.UseLazyLoadingProxies();
            }
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CategoryWiseProducts>(entity =>
            {
                entity.HasNoKey();
                entity.ToView("CategoryWiseProducts");
            });
        }
    }
}
