﻿using System.ComponentModel.DataAnnotations;

namespace Vertiv.PurchaseOrder.Entities
{
    public class Product
    {
        public int ProductId { get; set; }
        [StringLength(100)]
        public string ProductName { get; set; }=string.Empty;
        [StringLength(500)]
        public string Description { get; set; } = string.Empty;
        public decimal UnitPrice { get; set; }
        public int AvailableQuantity { get; set; }
        public int CategoryId { get; set; }
        public virtual Category Category { get; set; }
        public virtual ICollection<OrderDetail>? OrderDetails { get; set; }

    }
}
