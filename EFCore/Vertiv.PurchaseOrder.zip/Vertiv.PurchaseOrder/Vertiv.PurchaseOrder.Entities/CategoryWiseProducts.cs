﻿namespace Vertiv.PurchaseOrder.Entities
{
    public class CategoryWiseProducts
    {
        public string CategoryName { get; set; } = string.Empty;
        public string ProductName { get; set; } = string.Empty;
        public decimal UnitPrice { get; set; }
        public int AvailableQuantity { get; set; }
    }
}
