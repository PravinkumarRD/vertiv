﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Vertiv.PurchaseOrder.Entities
{
    public class Customer
    {
        public int CustomerId { get; set; }
        [Column(TypeName ="varchar(50)")]
        public string ContactName { get; set; } = string.Empty;
        [Column(TypeName = "varchar(50)")]
        public string City { get; set; } = string.Empty;
        [Column(TypeName = "datetime")]
        public DateTime BirthDate { get; set; }
        [NotMapped]
        public int SocialId { get; set; }
        public virtual ICollection<Order>? Orders { get; set; }
    }
}
